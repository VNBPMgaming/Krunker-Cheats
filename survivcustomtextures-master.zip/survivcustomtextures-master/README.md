# survivcustomtextures
A hosting place for the Resource Override JSON texture changer for surviv.io

HI?
